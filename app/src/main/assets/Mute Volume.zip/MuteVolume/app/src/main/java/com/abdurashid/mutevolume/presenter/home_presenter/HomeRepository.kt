package com.abdurashid.mutevolume.presenter.home_presenter

import android.content.Context
import androidx.room.Room
import com.abdurashid.mutevolume.db.DayListDao
import com.abdurashid.mutevolume.db.MyDatabase
import com.abdurashid.mutevolume.db.Today
import com.abdurashid.mutevolume.presenter.MainContract
import io.reactivex.Single
import io.reactivex.schedulers.Schedulers

class HomeRepository : MainContract.Model {

   lateinit var database : MyDatabase

var dao : DayListDao? = null
    override fun context(context: Context) {
       database = Room.databaseBuilder(context, MyDatabase::class.java, "database").build()
         dao = database.dao()
    }

    override fun addToDB(list: ArrayList<Today>) {
        dao!!.addList(list)
    }

    override fun getInDB(): Single<ArrayList<Today>> {
        return dao!!.getAll().observeOn(Schedulers.io()).subscribeOn(Schedulers.io())
    }


}
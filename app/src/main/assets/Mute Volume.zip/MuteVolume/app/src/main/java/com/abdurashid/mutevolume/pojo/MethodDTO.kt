package pojo
data class MethodDTO(
	val id: Int? = null,
	val name: String? = null,
	val params: ParamsDTO? = null
)
package pojo
data class WeekdayDTO(
	val en: String? = null,
	val ar: String? = null
)
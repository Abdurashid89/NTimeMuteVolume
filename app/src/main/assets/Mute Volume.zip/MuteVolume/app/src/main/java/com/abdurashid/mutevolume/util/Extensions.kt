package com.abdurashid.mutevolume.util

import android.view.View
import java.text.SimpleDateFormat
import java.util.*


fun View.visible(visisble: Boolean) {
    this.visibility = if (visisble) View.VISIBLE else View.GONE
}


fun Date.toString(format: String, locale: Locale = Locale.US): String {
    val formatter = SimpleDateFormat(format, locale)
    return formatter.format(this)
}

fun getCurrentDateTime(): Date {
    return Calendar.getInstance().time
}

fun formatDate(): String {
    return getCurrentDateTime().toString("yyyy-MM-dd.hh.mm")
}


fun convertLongToTime(time: Long): String {
    val date = Date(time)
    val format = SimpleDateFormat("yyyy.MM.dd  hh:mm")
    return format.format(date)
}

fun currentTimeToLong(): Long {
    return System.currentTimeMillis()
}

fun convertDateToLong(date: String): Long {
    val df = SimpleDateFormat("yyyy.MM.dd.hh:mm")
    return df.parse(date).time
}

typealias SingleBlock <T> = (T) -> Unit

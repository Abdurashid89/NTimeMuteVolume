package pojo
data class ParamsDTO(
	val fajr: Int? = null,
	val isha: Int? = null
)
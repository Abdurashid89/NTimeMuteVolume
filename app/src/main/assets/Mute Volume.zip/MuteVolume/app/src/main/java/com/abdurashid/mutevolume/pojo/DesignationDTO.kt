package pojo
data class DesignationDTO(
	val abbreviated: String? = null,
	val expanded: String? = null
)
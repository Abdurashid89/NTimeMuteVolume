package com.abdurashid.mutevolume.ui

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.widget.ProgressBar
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.abdurashid.mutevolume.R
import com.abdurashid.mutevolume.db.Today
import com.abdurashid.mutevolume.net.visible
import com.abdurashid.mutevolume.presenter.MainContract
import com.abdurashid.mutevolume.presenter.home_presenter.HomePresenter
import com.abdurashid.mutevolume.presenter.home_presenter.HomeRepository
import com.abdurashid.mutevolume.receiver.FAJR
import com.abdurashid.mutevolume.receiver.MyWorker
import com.abdurashid.mutevolume.receiver.RESULT_KEY_FAJR
import com.abdurashid.mutevolume.ui.adapter.DataAdapter
import com.abdurashid.mutevolume.util.Times
import com.abdurashid.mutevolume.util.convertDateToLong
import com.labo.kaji.fragmentanimations.CubeAnimation
import net.NetWork
import java.util.*


@Suppress("UNCHECKED_CAST", "CAST_NEVER_SUCCEEDS")
class HomeFragment : BaseFragment(), MainContract.View {
    override val resId = R.layout.fragment_home

    var fajr = ""
    var sunrise = ""
    var dhuhr = ""
    var asr = ""
    var maghrib = ""
    var isha = ""

    val cal = Calendar.getInstance()
    lateinit var day: Today

    lateinit var progress: ProgressBar
    var rvData: RecyclerView? = null
    lateinit var adapter: DataAdapter

    lateinit var service: net.Service
    lateinit var presenter: HomePresenter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        service = NetWork().service
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rvData = view.findViewById(R.id.rvData)
        progress = view.findViewById(R.id.progress)

        presenter = HomePresenter(requireContext(), this, HomeRepository())
        presenter.netWork(service)
    }

    override fun onCreateAnimation(transit: Int, enter: Boolean, nextAnim: Int): Animation {
        return CubeAnimation.create(CubeAnimation.UP, enter, 1000)
    }

    override fun addItem(list: ArrayList<Today>) {
        adapter = DataAdapter(list)

        day = list[22]
        rvData!!.adapter = adapter

//        fajr = day.fajr.substring(0, 6)

//        sunrise = day.sunrise.substring(0, 6)

//        dhuhr = day.dhuhr.substring(0, 6)

//        asr = day.dhuhr.substring(0, 6)

//        maghrib = day.maghrib.substring(0, 6)

//        isha = day.isha.substring(0, 6)
        alarm()
    }

    override fun showProgress(isShow: Boolean) {
        progress.visible(isShow)
    }

    override fun showMessage(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    private fun alarm() {

        val year = cal.get(Calendar.YEAR).toString()
        val month = cal.get(Calendar.MONTH).toString()
        val day = cal.get(Calendar.DAY_OF_MONTH).toString()


        val times = Times(year, month, day, "2", "56")
        val millisecond = convertDateToLong(times.toPattern().toString())

        Log.d("TimesTest", convertDateToLong(times.toPattern().toString()).toString())

/*        val intent = Intent()
        intent.putExtra("TIME", System.currentTimeMillis())
        val pendingIntent = PendingIntent.getBroadcast(requireContext(), 1, intent, 0)
        val alarmManager: AlarmManager =
            requireActivity().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)

        Log.d("millisecond", "${calendar.timeInMillis} ${System.currentTimeMillis()}")
        if (calendar.timeInMillis == System.currentTimeMillis()) {
            requestMutePermission()
        }*/

        val myData = workDataOf(FAJR to millisecond)
        val myWork = OneTimeWorkRequestBuilder<MyWorker>()
            .setInputData(myData)
            .build()

        WorkManager.getInstance(requireContext())
            .enqueue(myWork)

        WorkManager.getInstance(requireContext()).getWorkInfoByIdLiveData(myWork.id)
            .observe(viewLifecycleOwner) { info ->
                if (info != null && info.state.isFinished) {

                    val fHourse = info.outputData.getBoolean(RESULT_KEY_FAJR, false)

                    if (fHourse) {
                        requestMutePermission()
                    }
                }
            }
    }


    private fun requestMutePermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT < 23) {
                audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                val notificationManager: NotificationManager =
                    requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager


                if (notificationManager.isNotificationPolicyAccessGranted) {
                    val audioManager: AudioManager =
                        requireContext().getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    kotlin.run { Thread.sleep(5000) }
                    audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT

                } else {
                    val intent =
                        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    startActivityForResult(intent, 1001)
                }

            }

        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            requestMutePermission()
        }
    }

}
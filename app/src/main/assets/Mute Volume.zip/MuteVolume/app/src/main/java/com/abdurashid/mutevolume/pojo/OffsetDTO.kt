package pojo
data class OffsetDTO(
	val imsak: Int? = null,
	val fajr: Int? = null,
	val sunrise: Int? = null,
	val dhuhr: Int? = null,
	val asr: Int? = null,
	val maghrib: Int? = null,
	val sunset: Int? = null,
	val isha: Int? = null,
	val midnight: Int? = null
)
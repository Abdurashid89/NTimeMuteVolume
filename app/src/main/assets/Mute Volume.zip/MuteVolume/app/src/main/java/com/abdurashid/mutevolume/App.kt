package com.abdurashid.mutevolume

import android.app.Application

class App : Application() {
/*

    override fun onCreate() {
        super.onCreate()
        database = Room.databaseBuilder(this, MyDatabase::class.java, "database.db").build()
    }

    fun getMyDataBase() : MyDatabase {
        return database!!
    }


    companion object{
        var database: MyDatabase? = null
    }*/
}
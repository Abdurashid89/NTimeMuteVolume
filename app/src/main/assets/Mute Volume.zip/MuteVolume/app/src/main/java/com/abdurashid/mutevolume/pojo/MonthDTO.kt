package pojo
data class MonthDTO(
	val number: Int? = null,
	val en: String? = null,
	val ar: String? = null
)
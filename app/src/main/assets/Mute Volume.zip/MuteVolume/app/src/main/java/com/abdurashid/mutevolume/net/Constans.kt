package net

val BASE_URL = "http://api.aladhan.com/v1/"

///method/month/year/2020&school/latitude/longitude/
//?method=2&month=12&year=2020&school=1&latitude=41.300398700358386&longitude=69.24361426456768"

//methodById
/**
 * monthByID
 * yearById
 * schoolById
 * latitude and longitude Double
 * */
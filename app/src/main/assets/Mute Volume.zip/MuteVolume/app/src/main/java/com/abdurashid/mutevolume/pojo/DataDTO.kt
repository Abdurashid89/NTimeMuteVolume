package pojo

data class DataDTO(
	val timings: TimingsDTO? = null,
	val date: DateDTO? = null,
	val meta: MetaDTO? = null
)
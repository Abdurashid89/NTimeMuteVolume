/*
package com.example.mutevolume.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Bundle

class MyReceiver : BroadcastReceiver() {

val audioManager : AudioManager? = null

    override fun onReceive(context: Context?, intent: Intent?) {
val action = intent!!.action

   val time =  intent.extras
    if (action.equals("TIME")){

        sendTime(time)
    }
    }

    private fun sendTime(context: Context,time: Bundle) {
      context.sendBroadcast()
    }

*/
/*    private fun requestMutePermission(context: Context,intent: Intent) {
        try {
            if (android.os.Build.VERSION.SDK_INT < 23) {
                audioManager!!.ringerMode = AudioManager.RINGER_MODE_SILENT
            } else if (android.os.Build.VERSION.SDK_INT >= 23) {
                val notificationManager: NotificationManager =
                    context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager


                if (notificationManager.isNotificationPolicyAccessGranted) {
                    val audioManager: AudioManager =
                        requireContext().getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    audioManager.ringerMode = AudioManager.RINGER_MODE_VIBRATE
                    kotlin.run { Thread.sleep(5000) }
                    audioManager.ringerMode = AudioManager.RINGER_MODE_SILENT

                } else {
                 val   intent =
                        Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                    startActivityForResult(intent, 1001)
                }

            }

        } catch (e: SecurityException) {
            e.printStackTrace()
        }
    }*//*

}*/

package com.abdurashid.mutevolume.data

data class ResData(val message: String, val success: Boolean)